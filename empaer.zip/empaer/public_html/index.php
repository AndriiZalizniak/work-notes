<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="utf-8">
		<title>«Empaer-Motors» — бизнес-центр класса «А»</title>
		<meta name="keywords" content="офис, офисы, офис в сумах, бизнес-центр Сумы, Empaer, Empaer-motors" />
		<meta name="description" content="Бизнес-центр класса «А» в г. Сумы" />
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:300,400&subset=latin,cyrillic' rel='stylesheet' type='text/css'>        
        <link rel="stylesheet" type="text/css" href="css/reset-min.css">
        <link rel="stylesheet" type="text/css" href="css/style.css?xxx2">
        <link rel="stylesheet" type="text/css" href="css/additional/add-buttons.css">
        <script type="text/javascript" src="js/jquery-1.7.1.js"></script>
        <script type="text/javascript" src="js/js.js"></script>
        <script type="text/javascript" src="js/waypoints.min.js"></script>
		<script type="text/javascript">if ( /Android|webOS|iPhone|iPad|iPod|BlackBerry|Windows Phone/i.test(navigator.userAgent) ) { window.location.replace("http://m." + window.location.hostname) }</script>
        <link rel="shortcut icon" href="/img/fav.ico" type="image/x-icon">
        <link rel="icon" href="/img/fav.ico" type="image/x-icon">
		
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-42370768-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
		
    </head>
    <!--[if lt IE 7 ]> <body class="ie6 locked"> <![endif]--><!--[if IE 7 ]>    <body class="ie7 locked"> <![endif]--><!--[if IE 8 ]>    <body class="ie8 locked"> <![endif]--><!--[if gt IE 8 ]>    <body class="ie9 locked"> <![endif]-->
    <!--[if !IE]><!-->
    <body>
    <!--<![endif]-->
	
    <!--End Slide 1-->
	<div class="slide" id="slide1" data-slide="1">
        <a href="#" class="lightBox"><span>Узнайте о рекламных возможностях Empaer Motors</span></a>
        <h1>Бизнес центр класса «А»</h1>
        <!--h2>В самом центре Сум.</h2-->
    </div>
    <!--End Slide 1-->
    <script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false"></script>

    <div class="slide bcContainer" id="slide2" data-slide="2">
        <div class="slideContainer">
        </div>
    </div>
    <!--End Slide 2-->
    <div class="slide bcContainer" id="slide3" data-slide="3">
        <div class="slideContainer">
        </div>
    </div>
    <!--End Slide 3-->
    <div class="slide bcContainer" id="slide4" data-slide="4">
        <div class="slideContainer">
        </div>
    </div>
    <!--End Slide 3-->
    <div class="slide bcContainer" id="slide5" data-slide="5">
        <div class="slideContainer">
        </div>
    </div>
    <!--End Slide 3-->
    <div class="slide bcContainer" id="slide6" data-slide="6">
        <div class="slideContainer">
        </div>
    </div>
    <!--End Slide 3-->
    <div class="slide bcContainer" id="slide7" data-slide="7">
        <div class="slideContainer">
        </div>
    </div>
    <!--End Slide 3-->
    <div class="slide bcContainer" id="slide8" data-slide="8">
        <div class="slideContainer">
        </div>
    </div>
    <!--End Slide 3-->
    <div class="slide bcContainer" id="slide9" data-slide="9">
        <div class="slideContainer">
        </div>
    </div>
    <!--End Slide 3-->
    
    <div class="slide pgContainer" id="slide10" data-slide="10">
        <div class="slideContainer">
            <div class="pattern"></div>        
            <h3>Офисы</h3>
                <div class="ofice_desc">
                    БЦ «Эмпаер Моторс» предлагает современные комфортные офисы класса «А» площадью от 17 до 65 кв.м. 
                    Удобная планировка, индивидуальная система климат-конроля, полное техническое обслуживание, 
                    ежедневная уборка — мы выстраиваем с нашими партнёрами-арендаторами долгосрочные стабильные отношения, 
                    создавая максимально-комфортные условия для их пребывания в бизнес-центре.
                </div>
                
                <h4 class="office_title">В каждом офисе</h4>
                <ul class="ofice_equipment">
                    <li>Индивидуальная система климат-контроля</li>
                    <li>Высокоскоростной интернет и телефон</li>
                    <li>Ежедневная уборка</li>
                    <li>Полное техническое обслуживание</li>
                    <li>Максимальный уровень звукоизоляции</li>
                </ul>
                
           <ul id="selectFloorMenu" class="clearfix">
                <li>
                    <a href="#floor1" class="selected"><span>1-й этаж</span></a>
                </li>
                <li>
                    <a href="#floor2"><span>2-й этаж</span></a>
                </li>
                <li>
                    <a href="#floor3"><span>3-й этаж</span></a>
                </li>
            </ul>                
                
                <div id="floor1" class="floor1 floorSlide">
                    <a href="#" class="fl101"></a>
                    <a href="#" class="fl102"></a>
                    <a href="#" class="fl103"></a>
                    <a href="#" class="fl104"></a>
                    <a href="#" class="fl105"></a>
                    <a href="#" class="fl106"></a>
                    <a href="#" class="fl107"></a>
                    <a href="#" class="fl108"></a>
                    <a href="#" class="fl109"></a>
                    <a href="#" class="fl110"></a>
                    <a href="#" class="fl111"></a>
                    <a href="#" class="fl112"></a>
                    <a href="#" class="fl113"></a>
                    <a href="#" class="fl114"></a>
                    <a href="#" class="fl115"></a>
                    <a href="#" class="fl116"></a>
                </div>

                <div id="floor2" class="floor2 floorSlide" style="display: none;">
                    <a href="#" class="fl201"></a>
                    <a href="#" class="fl203"></a>
                    <a href="#" class="fl204-202"></a>
                    <a href="#" class="fl205"></a>
                    <a href="#" class="fl207"></a>
                    <a href="#" class="fl208-206"></a>
                    <a href="#" class="fl209"></a>
                    <a href="#" class="fl211"></a>
                    <a href="#" class="fl212-210"></a>
                    <a href="#" class="fl213"></a>
                    <a href="#" class="fl215"></a>
                    <a href="#" class="fl216-214"></a>
                    <a href="#" class="fl217"></a>
                    <a href="#" class="fl219"></a>
                    <a href="#" class="fl220-218"></a>
                    <a href="#" class="fl221"></a>
                    <a href="#" class="fl222"></a>
                    <a href="#" class="fl223"></a>
                </div>

                <div id="floor3" class="floor3 floorSlide" style="display: none;">
                    <a href="#" class="fl301"></a>
                    <a href="#" class="fl302"></a>
                    <a href="#" class="fl303"></a>
                    <a href="#" class="fl304"></a>
                    <a href="#" class="fl305"></a>
                    <a href="#" class="fl306"></a>
                    <a href="#" class="fl307"></a>
                    <a href="#" class="fl308"></a>
                    <a href="#" class="fl309"></a>
                    <a href="#" class="fl310"></a>
                    <a href="#" class="fl311"></a>
                    <a href="#" class="fl312"></a>
                    <a href="#" class="fl313"></a>
                    <a href="#" class="fl314"></a>
                    <a href="#" class="fl315"></a>
                    <a href="#" class="fl316"></a>
                    <a href="#" class="fl317"></a>
                    <a href="#" class="fl318"></a>
                    <a href="#" class="fl319"></a>
                    <a href="#" class="fl320"></a>
                    <a href="#" class="fl321"></a>
                    <a href="#" class="fl322"></a>
                </div>
        

        </div>
    </div>    
    
    <div class="slide pgContainer" id="slide11" data-slide="11">
        <div class="slideContainer">
            <div class="pattern"></div>        
            <h3>Фотогалерея</h3>
                <img src="/img/top-shadow.png" class="top-shadow"/>
                <div id="photoGallery">
                    <img src="/img/photos/1.jpg" id="photo1" class="photo"/>
                    <img src="/img/left-top.png" class="l-t"/>
                    <img src="/img/left-bottom.png" class="l-b"/>
                    <img src="/img/right-top.png" class="r-t"/>
                    <img src="/img/right-bottom.png" class="r-b"/>
                    <div class="loadingIcon" style="display: none;"></div>
                    <a href="#" class="leftPhotoBtn"></a>
                    <a href="#" class="rightPhotoBtn"></a>
                </div>
    

        </div>
    </div>
    <!--End Slide 3-->
    <div class="slide arendators" id="slide12" data-slide="12">
        <div class="slideContainer">
            <h3>Арендаторы</h3>
            <ul id="arendatorsMenu" class="clearfix">
                <li>
                    <a href="#" class="selected"><span>Нулевой этаж</span></a>
                </li>
                <li>
                    <a href="#"><span>1-й этаж</span></a>
                </li>
                <li>
                    <a href="#"><span>2-й этаж</span></a>
                </li>
                <li>
                    <a href="#"><span>3-й этаж</span></a>
                </li>
            </ul>
			<?php
				$data = file_get_contents('admin/data.php');
				$data = json_decode($data, TRUE);
				$classes = array('A', 'B', 'C');
				$iteration = 0;
			?>
			<ul id="arendatorSlides">
				<li id="arendatorSlide0" class="arendatorSlide">
					<?php foreach ($data[1] as $row): ?>
						<ul class="block<?php echo $classes[$iteration++]; ?>">
							<li class="arendatorLogo"></li>
							<li class="title">
								<?php echo $row['title']; ?>
							</li>
							<li class="desc">
								<?php echo $row['description']; ?>
							</li>
							<li class="phone">
								<?php echo $row['phone']; ?>
							</li>
							<li class="link">
								<?php if ($row['web']): ?>
								<a href="http://<?php echo $row['web']; ?>"><?php echo $row['web']; ?></a>  
								<?php endif; ?>
							</li>
						</ul>
					<?php endforeach; ?>
				</li>
				<li id="arendatorSlide1" style="display: none;"  class="arendatorSlide">   
					<?php foreach ($data[2] as $row): ?>                
						<ul class="block">
							<li class="title">
								<?php echo $row['title']; ?>
							</li>
							<li class="desc">
								<?php echo $row['description']; ?>
							</li>
							<li class="phone">
								<?php echo $row['phone']; ?>
							</li>
							<li class="appartment">
								<?php echo $row['office']; ?>
							</li>
							<li class="link">
								<?php if ($row['web']): ?>
								<a href="http://<?php echo $row['web']; ?>"><?php echo $row['web']; ?></a>  
								<?php endif; ?>
							</li>
						</ul>
					<?php endforeach; ?>
				</li>
				<li id="arendatorSlide2" style="display: none;" class="arendatorSlide">
					<?php foreach ($data[3] as $row): ?>                
						<ul class="block">
							<li class="title">
								<?php echo $row['title']; ?>
							</li>
							<li class="desc">
								<?php echo $row['description']; ?>
							</li>
							<li class="phone">
								<?php echo $row['phone']; ?>
							</li>
							<li class="appartment">
								<?php echo $row['office']; ?>
							</li>
							<li class="link">
								<?php if ($row['web']): ?>
								<a href="http://<?php echo $row['web']; ?>"><?php echo $row['web']; ?></a>  
								<?php endif; ?>
							</li>
						</ul>
					<?php endforeach; ?>
				</li>
				<li id="arendatorSlide3" style="display: none;" class="arendatorSlide">
					<?php foreach ($data[4] as $row): ?>
						<ul class="block">
							<li class="title">
								<?php echo $row['title']; ?>
							</li>
							<li class="desc">
								<?php echo $row['description']; ?>
							</li>
							<li class="phone">
								<?php echo $row['phone']; ?>
							</li>
							<li class="appartment">
								<?php echo $row['office']; ?>
							</li>
							<li class="link">
								<?php if ($row['web']): ?>
								<a href="http://<?php echo $row['web']; ?>"><?php echo $row['web']; ?></a>  
								<?php endif; ?>
							</li>
						</ul>
					<?php endforeach; ?>
				</li>
			</ul>
		</div>
	</div>
    <!--End Slide 3-->
    <div class="slide contactContainer" id="slide13" data-slide="13">
        <div class="slideContainer">
            <h3>Контакты</h3>
            <p>
                40000, Украина, 
                <br/>
                г. Сумы, ул. Казацкий Вал, 2б
                <br/>
            </p>
            <p class="phoneNumbers">
                <strong>Контактные телефоны:</strong>
                <br/>
                +38 (0542) 77-17-42
                <br/>
                +38 (0542) 77-17-43
                <br/>
                +38 (050) 9-025-025
                <br/>
            </p>
            <div id="city-map-contact">
            </div>
            <div class="contactForm">
                <h4>Напишите нам!</h4>
                <form action="#" method="post">
                    <input type="text" id="nameGC" name="nameGC" class="default" value="Ваше имя"/>
                    <input type="text" id="emailGC" name="emailGC" class="default" value="Электронная почта или телефон"/>
                    <textarea rows="4" id="questionGC" name="questionGC" class="default" cols="50">Ваш вопрос</textarea>
                    <a id="sendContactInfo" href="#">Отправить</a>
                </form>
                <span id="nameError" class="errorGC" style="display: none;">введите свое имя</span>
                <span id="emailError" class="errorGC" style="display: none;">неверный формат</span>
                <span id="questionError" class="errorGC" style="display: none;">отсутствует текст вопроса</span>
            </div>
            <div id="thankYou" style="display: none;">
                <h5>Сообщение отправлено!</h5>
                <span>Мы постараемся ответить на него как можно скорее.</span>
                <a href="#">Написать еще.</a>
            </div>
            
        </div>
    </div>
    </div>
    <!--End Slide 3-->
    <div class="footerFix" id="slide14" data-slide="14">
    </div>
    <a href="#" class="logo"></a>
    <ul id="menu" class="mainMenu">
        <li>
            <a href="#" class="bisnessCenter">Бизнес-центр</a>
        </li>
        <li>
            <a href="#" class="office">Офисы</a>
        </li>
        <li>
            <a href="#" class="photoGallery">Фотогалерея</a>
        </li>
        <li>
            <a href="#" class="lessor">Арендаторы</a>
        </li>
        <li>
            <a href="#" class="contacts">Контакты</a>
        </li>
    </ul>
	
	<div class="b-add-buttons">
		<a href="/materials/Business_Center-Empaer_Motors.pdf" class="b-add-buttons__pres">
			<span class="b-add-buttons__pres-text">Презентация бизнес-центра</span>
		</a>
		<a href="https://www.facebook.com/empaer.motors" class="b-add-buttons__social">
			<span class="b-add-buttons__social-text">Мы на Facebook</span>
		</a>
	</div>
	
    <div class="phoneFixed">
        +38 (0542)<b>77-17-42</b>
    </div>
    <a href="#" class="topMapLink mapPopupLink"><span>карта проезда</span></a>
  
    <div id="subBlock2" class="slide2Block" style="display: none;">
        БЦ «Empaer Motors», имеющий премиальное месторасположение, высокотехнологичное здание, наивысший уровень комфорта, безопасности и сервиса, соответсвует наивысшей степени классификации бизнес-недвижимости &mdash; классу «А».
        
        
    </div>
    <div id="subBlock3" class="slide2Block" style="display: none;">
        БЦ «Empaer Motors» располагается в историческом центре города Сумы &mdash; на улице Казацкий Вал, 2б.  У здания высокая проходимость и доступность свободного проезда с Покровской площади и ул. Терезова.
       <a href="#" class="mapPopupLink slide2MapLink"><span>посмотреть на карте</span></a>

    </div>
    <div id="subBlock4" class="slide2Block" style="display: none;">
        Существующая планировка бизнес-центра позволяет подобрать каждому арендатору необходимое по площади и функциональности помещение. 
    </div>
    <div id="subBlock5" class="slide2Block" style="display: none;">
        Все офисы бизнес центра оснащены современной индивидуальной системой автономного кондиционирования и отопления, позволяющей создавать комфортную температуру в каждом помещении в любое время года.
    </div>
    <div id="subBlock6" class="slide2Block" style="display: none;">
        БЦ «Empaer Motors» находится под круглосуточной физической охраной и оснащен современной системой видеонаблюдения. 
    </div>
    <div id="subBlock7" class="slide2Block" style="display: none;">
        Офисы БЦ «Empaer Motors» ежедневно обслуживаются высококлассным персоналом, обеспечивающим работоспособность всех систем здания и каждого помещения в отдельности, предоставляющим услуги клининга. 
    </div>
    <div id="subBlock8" class="slide2Block" style="display: none;">
        Охраняемый паркинг расчитан на 35 машиномест. Въезд-выезд оборудован автоматическим шлагбаумом с индивидуальным управлением. 
    </div>
    
    <div id="popupAds" style="display: none;">
        <h4>Реклама на ситилайтах в центре Сум!</h4>
        <div class="promo">Отличные цены и премиальное размещение!</div>
        <div class="promo2">
            Бизнес-центр «Empaer Motors»  предлагает вам размещение рекламы на ситилайтах в историческом центре г. Сумы, 
             на улице Казацкий Вал.  Рекламные носители имеют 100% просматриваемость, 
             а улица отличную проходимость! 
             Скидки до 50% и печать в подарок при заказе ситилайта на 6 месяцев!
        </div>
        <div class="promo3">
            Заказ по телефону
        </div>       
        <div class="promo4">
            <span>+38</span> <i>(050)</i> <b>9-025-025</b>
        </div>        
        <div class="promo5">
            <span>+38</span> <i>(0542)</i> <b>77-17-42</b>
        </div>
        <div class="promo6">
            <span>+38</span> <i>(0542)</i> <b>77-17-43</b>
        </div>
        <a href="#" class="closeButton"></a>
    </div>
    
    <div id="popupMap" style="display: none;">
        <h4>Сумы, ул. Казацкий Вал, 2б</h4>
        <div id="cityMap" class="cityMap"></div>
      
        <a href="#" class="closeButton"></a>
    </div>    


    <div id="popupFeedback" style="display: none;">
        <h4>Закажите офис сейчас!</h4>
        <form action="#" method="post">
            <input type="text" id="nameGC2" name="nameGC2" class="default" value="Ваше имя"/>
            <input type="text" id="emailGC2" name="emailGC2" class="default" value="Электронная почта или телефон"/>
            <textarea rows="4" id="questionGC2" name="questionGC2" class="default" cols="50">Ваш вопрос</textarea>
            <a id="sendContactInfo2" href="#">Отправить</a>
        </form>
        <span id="nameError2" class="errorGC" style="display: none;">введите свое имя</span>
        <span id="emailError2" class="errorGC" style="display: none;">неверный формат</span>
        <span id="questionError2" class="errorGC" style="display: none;">отсутствует текст вопроса</span>


        <div id="photoGallery2">
            <img src="/img/floors/photos/1.png" id="floor-photo1" class="photo"/>
            <div class="loadingIcon" style="display: none;"></div>
            <a href="#" class="leftPhotoBtn"></a>
            <a href="#" class="rightPhotoBtn"></a>
        </div>
                
                      
        <a href="#" class="closeButton"></a>
    </div>  
    
    <a href="#" class="nextSlideButton"><b class="down"></b><b class="up" style="display: none;"></b></a>
  <div id="subSlide2" style="display: none;">
        <h2>Лучшее место</h2>
			<h2 class="second">для успешного бизнеса</h2>
        <ul id="slide2Menu">
            <li>
                <a href="#" class="selected">Премиальное расположение</a>
            </li>
            <li>
                <a href="#">Универсальная планировка</a>
            </li>
            <li>
                <a href="#">Климат-комфорт</a>
            </li>
            <li>
                <a href="#">Безопасность</a>
            </li>
            <li>
                <a href="#">Сервис</a>
            </li>
            <li>
                <a href="#">Паркинг </a>
            </li>
        </ul>
        
        <a href="#freePlaces" class="freePlaces">Узнайте о наличии свободных офисов</a>
        
        <!-- <div class="conf_hall">
            <h5>Конференц-зал на 40 мест</h5>
            <div>
                Воспользуйтесь услугами современного конференц-зала в центре города всего за 80 грн/час.
                Зарезервируйте по телефону <span class="phone">+38 (050) 9-025-025</span> или напишите на <a href="mailto:company@empaer-motors.com.ua" class="mail">company@empaer-motors.com.ua</a>
            </div>
        </div> -->
        



        
    </div>    
    <ul class="socialButtons">
        <li>
            <a href="#" class="fb" onclick="Share.facebook('http://empaer-motors.com.ua/','Бизнес Центр «Empaer Motors»','http://test.nikitos.com/img/social-logo.jpg','БЦ «Empaer Motors», имеющий премиальное месторасположение, высокотехнологичное здание, наивысший уровень комфорта, безопасности и сервиса, соответсвует наивысшей степени классификации бизнес-недвижимости -- классу «А».')"></a>
        </li>
        <li>
            <a href="#" class="vk" onclick="Share.vkontakte('http://empaer-motors.com.ua/','Бизнес Центр «Empaer Motors»','http://test.nikitos.com/img/social-logo.jpg','БЦ «Empaer Motors», имеющий премиальное месторасположение, высокотехнологичное здание, наивысший уровень комфорта, безопасности и сервиса, соответсвует наивысшей степени классификации бизнес-недвижимости -- классу «А».')"></a>
        </li>
        <li>
            <a href="#" class="tw" onclick="Share.twitter('http://empaer-motors.com.ua/','Бизнес Центр «Empaer Motors»')"></a>
        </li>
    </ul>    
    <a href="http://crisp-studio.com/" class="madeBy"></a>
    
    <script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-38187257-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
  
</script>
    
</body>
</html>
