<?php
	/*
		C O N F I G   A N D   U T I L S
	*/
	session_start();
	define('SESSION_NAME', 'emsid');
	define('LOGIN', 'admin');
	define('PASS', 'rhinoceros2014');
	define('CPF_FOLDER', 'admin/');
	define('CPF_ROOT_DIR', str_replace('\\', '/', dirname(__FILE__)) . '/');
	define('CPF_ROOT_URL', sprintf('http://%s/%s', $_SERVER['HTTP_HOST'], CPF_FOLDER));

	$CPF_ERRORS = array();
	$EMPIRE_FLOORS = array(1 => 'Цокольный этаж', 2 => '1-й этаж', 3 => '2-й этаж', 4 => '3-й этаж');

	// Helpers
	function d($d, $exit = FALSE) { echo '<br /><br /><br /><br />'; echo '<pre>'; print_r($d); echo '</pre>'; if ($exit) exit; }
	function nl() { return "\r\n"; }
	function tab($n = 0) { return str_repeat("\t", $n); }
	function post($key) { return isset($_POST[$key]) ? $_POST[$key] : FALSE; }

	// Auth
	function login()
	{
		if (($login = post('login')) !== FALSE && ($pass = post('password'))!== FALSE && $login == LOGIN && $pass == PASS)
		{
			$_SESSION[SESSION_NAME] = md5(LOGIN.PASS);
			refresh();
			return TRUE;
		}
		return FALSE;
	}

	function logout()
	{
		unset($_SESSION[SESSION_NAME]);
		redirect('index.php');
	}

	function isLoggedIn()
	{
		$i = isset($_SESSION[SESSION_NAME]);
		return $i;
	}

	// Forms
	function isPost()
	{
		return isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] == 'POST';
	}

	function isAjax()
	{
		return isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';
	}

	function redirect($url)
	{
		header(sprintf('Location: %s', $url));
		exit();
	}

	function refresh()
	{
		redirect($_SERVER['REQUEST_URI']);
	}

	// Files
	function openFile($write = FALSE) { $fp = fopen('data.php', $write ? 'w+' : 'r'); return $fp; }

	function getData()
	{
		$data = file_get_contents('data.php');
		return json_decode($data, TRUE);
	}

	function saveData($data)
	{
		$fp = openFile($write = TRUE);
		fprintf($fp, '%s', json_encode($data));
	}

	/*
		C R U D
	*/
	function getObjFromPost()
	{
		$EMPIRE_OFFICE = array(
			'photo' => '',
			'title' => '',
			'description' => '',
			'phone' => '',
			'office' => '',
			'web' => ''
		);
		$temp = $EMPIRE_OFFICE;
		foreach ($EMPIRE_OFFICE as $key => $value)
		{
			if (($tmp = post($key)) !== FALSE)
				$temp[$key] = $tmp;
		}
		return $temp;
	}

	/*
		A P P
	*/
	if (isPost())
	{
		if (!isLoggedIn())
		{
			if (!login())
			{
				$CPF_ERRORS[] = 'Неверный логин или пароль';
			}
		}
		elseif (isAjax() && ($method = post('method')) !== FALSE && ($floor = post('floor')) !== FALSE)
		{
			try
			{
				$data = getData();
				if ($method == 'add')
				{
					$row = getObjFromPost();
					$id = time();
					$data[$floor][$id] = $row;
					saveData($data);
				}
				elseif ($method == 'edit' && ($id = post('id')) !== FALSE)
				{
					$row = getObjFromPost();
					$data[$floor][$id] = $row;
					saveData($data);
				}
				elseif ($method == 'move' && ($id = post('id')) !== FALSE && ($direction = post('direction')) !== FALSE)
				{
					$rows = $data[$floor];
					if ($direction == 'up')
					{
						$prev = null;
						foreach ($rows as $rowkey => $row)
						{
							if ($rowkey == $id)
								break;
							$prev = $rowkey;
						}
						if (!is_null($prev))
						{
							$temp = $data[$floor][$prev];
							$data[$floor][$prev] = $data[$floor][$id];
							$data[$floor][$id] = $temp;
						}
					}
					elseif ($direction == 'down')
					{
						$next = null;
						foreach ($rows as $rowkey => $row)
						{
							if (!is_null($next))
							{
								$next = $rowkey;
								break;
							}
							if ($rowkey == $id)
							{
								$next = $rowkey;
							}
						}
						if (!is_null($next))
						{
							$temp = $data[$floor][$next];
							$data[$floor][$next] = $data[$floor][$id];
							$data[$floor][$id] = $temp;
						}
					}
					saveData($data);
					echo json_encode('ok');
					exit;
				}
				elseif ($method == 'remove' && ($id = post('id')) !== FALSE)
				{
					unset($data[$floor][$id]);
					saveData($data);
					echo json_encode('ok');
					exit;
				}
				elseif ($method == 'get' && ($id = post('id')) !== FALSE)
				{
					echo json_encode($data[$floor][$id]);
					exit;
				}
			}
			catch (Exception $e)
			{
				d($e->getMessage());
			}
		}
		elseif (isAjax() && ($method = post('method')) !== FALSE)
		{
			if ($method == 'load')
			{
				$data = getData();
				echo json_encode($data);
				exit;
			}
		}
	}
	else
	{
		if (isset($_GET['logout']) && isLoggedIn())
		{
			logout();
		}
	}
	$data = getData();

	require_once('template.php');
?>