<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="ru">
<head>
	<title>Empaer Motors Admin</title>
	<base href="<?php echo CPF_ROOT_URL; ?>" />
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<link type="text/css" href="bootstrap/css/bootstrap.css" rel="stylesheet" media="screen" />
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.js"></script>
	<script type="text/javascript" src="js/jquery.validate.min.js"></script>
	<script type="text/javascript" src="js/jquery.form.min.js"></script>
</head>
<body>
	<div class="cpf-wrap">
		<header class="navbar navbar-inverse navbar-fixed-top bs-docs-nav" role="banner">
			<div class="container">
				<div class="navbar-header">
					<a class="navbar-brand" href="<?php echo CPF_ROOT_URL; ?>">Empaer Motors</a>
				</div>
				<?php if (isLoggedIn()): ?>
				<ul class="nav navbar-nav navbar-right">
					<li><a href="index.php?logout">Выйти</a></li>
				</ul>
				<?php endif; ?>
			</div>
		</header>
		<div class="container">
			<br /><br /><br /><br />

			<?php if (!isLoggedIn()): ?>
				<div class="row">
					<div class="col-md-4 col-md-offset-4">
						<?php if (count($CPF_ERRORS) > 0): ?>
							<div class="alert alert-danger">
								<?php foreach($CPF_ERRORS as $error): ?>
									<p><?php echo $error; ?></p>
								<?php endforeach; ?>
							</div>
						<?php endif; ?>
						<form action="" method="post" id="cpf-page-form" class="well">
							<img src="../img/logo.png" width="160" height="140" alt="" class="center-block" />
							<div class="form-group">
								<label for="login" class="control-label">Логин:</label>
								<div class="controls">
									<input type="text" id="login" name="login" maxlength="255" value="" class="form-control field_login">
								</div>
							</div>
							<br />
							<div class="form-group">
								<label for="password" class="control-label">Пароль:</label>
								<div class="controls">
									<input type="password" id="password" name="password" value="" class="form-control field_login">
								</div>
							</div>
							<br />
							<div style="width: 210px; margin: 0px auto; padding: 10px 0;">
								<button class="btn btn-primary" type="submit">Войти</button>
								<a href="../" class="btn">Перейти на сайт</a>
							</div>
						</form>
					</div>
				</div>
			<?php else: ?>
				<div class="row">
					<div class="col-md-12">
						<ul class="nav nav-tabs">
							<?php foreach ($EMPIRE_FLOORS as $key => $floor): ?>
								<li<?php if ($key == 1): ?> class="active"<?php endif; ?>><a href="#floor-<?php echo $key; ?>"><?php echo $floor; ?></a></li>
							<?php endforeach; ?>
						</ul>

						<div class="tab-content">
							<?php foreach ($EMPIRE_FLOORS as $key => $floor): ?>
								<div class="tab-pane<?php if ($key == 1): ?> active<?php endif; ?>" id="floor-<?php echo $key; ?>">
									<br />
									<?php if ($key != 1): ?>
									<a href="" class="btn btn-info add-row" data-floor="<?php echo $key; ?>" data-toggle="modal" data-target="#modalAdd">Добавить арендатора</a>
									<br /><br />
									<?php endif; ?>
									<div class="tab-pane-content"></div>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
				</div>
			<?php endif; ?>
			<br />
		</div> <!-- /.container -->
		
		<div class="modal fade" id="modalAdd" tabindex="-1" role="dialog" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<form action="" method="post" class="b-form form-add">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
							<h4 class="modal-title">Добавить арендатора</h4>
						</div>
						<div class="modal-body">
							<div class="form-group">
								<label for="title" class="control-label">Название:</label>
								<div class="controls">
									<input type="text" id="title" name="title" maxlength="255" value="" class="form-control">
								</div>
							</div>
							<div class="form-group">
								<label for="title" class="control-label">Описание:</label>
								<div class="controls">
									<textarea id="description" name="description" class="form-control"></textarea>
								</div>
							</div>
							<div class="form-group">
								<label for="title" class="control-label">Офисы:</label>
								<div class="controls">
									<input type="text" id="office" name="office" maxlength="255" value="" class="form-control">
								</div>
							</div>
							<div class="form-group">
								<label for="title" class="control-label">Телефоны:</label>
								<div class="controls">
									<input type="text" id="phone" name="phone" maxlength="255" value="" class="form-control">
								</div>
							</div>
							<div class="form-group">
								<label for="title" class="control-label">Сайт:</label>
								<div class="controls">
									<input type="text" id="web" name="web" maxlength="255" value="" class="form-control">
								</div>
							</div>
						</div>
						<div class="modal-footer">
							<input type="hidden" name="id" id="id" value="" />
							<input type="hidden" name="method" id="method" value="add" />
							<input type="hidden" name="floor" id="floor" value="1" />
							<button type="button" class="modal-close btn btn-default" data-dismiss="modal">Отмена</button>
							<button type="submit" class="btn btn-primary">Добавить</button>
						</div>
					</form>
				</div><!-- /.modal-content -->
			</div><!-- /.modal-dialog -->
		</div><!-- /.modal -->

		<script type="text/javascript">
			$(document).ready(function(){

				<?php if (isLoggedIn()): ?>

					$('.nav-tabs a').click(function (e) {
						e.preventDefault()
						$(this).tab('show')
					});

					$('.add-row').click(function (e) {
						var floor = $(this).data('floor');
						$('.modal-body').find('input, textarea').val('');
						$('#floor').val(floor);
						$('#method').val('add');
						$('#id').val('');
						$('.modal-title').html('Добавить арендатора');
						$('.modal-footer .btn-primary').html('Добавить');
					});

					$('.b-form').validate({
						rules: {
							title: { required: true }
						},
						messages: {
							title: { required: "" }
						},
						highlight: function(element, errorClass) {
							$(element).parents('.form-group').addClass('has-error');
						},
						unhighlight: function(element, errorClass) {
							$(element).parents('.form-group').removeClass('has-error');
						},
						submitHandler: function(form) {
							$(form).ajaxSubmit();
							$('.modal-close').trigger('click');
							refreshData();
						}
					});

					function refreshData()
					{
						var template = '\
							<div class="well row">\
								<div class="col-md-11">\
									<h4>{title}</h4>\
									<h6>{description}</h6>\
									<p>{phone}</p>\
									<p>{office}</p>\
									<p>{web}</p>\
								</div>\
								<div class="col-md-1">\
									<a href="#" data-id="{uid}" data-floor="{floor}" class="move-up btn btn-default"><span class="glyphicon glyphicon-chevron-up"></span></a>\
									<a href="#" data-id="{uid}" data-floor="{floor}" class="move-down btn btn-default"><span class="glyphicon glyphicon-chevron-down"></span></a>\
									<a href="#" data-id="{uid}" data-floor="{floor}" data-toggle="modal" data-target="#modalAdd" class="edit btn btn-default"><span class="glyphicon glyphicon-edit"></span></a>\
									<a href="#" data-id="{uid}" data-floor="{floor}"onclick="return confirm(\'Действительно удалить эту запись?\')" class="remove btn btn-default"><span class="glyphicon glyphicon-remove"></span></a>\
								</div>\
							</div>\
						';
						$.ajax({
							type: "POST",
							url: "index.php",
							dataType: "JSON",
							data: { method: "load" }
						}).done(function( data ) { 
							for (var floor in data)
							{
								var content = $('#floor-'+floor+' .tab-pane-content');
								content.html('');
								var rows = data[floor];
								for (var id in rows)
								{
									var row = rows[id];
									var rowHtml = template;
									rowHtml = rowHtml.replace(/{uid}/g, id);
									rowHtml = rowHtml.replace(/{floor}/g, floor);
									for (var key in row)
									{
										var keyName = '{' + key + '}';
										rowHtml = rowHtml.replace(keyName, row[key]);
									}
									content.append(rowHtml);
								}
							}
							$('.tab-pane-content').each(function() {
								$(this).find('.well').first().find('.move-up').hide();
								$(this).find('.well').last().find('.move-down').hide();
								$('#floor-1').find('.move-down, .move-up, .remove').hide();
							});
							bindListeners();
						}).fail(function(jqXHR, textStatus, errorThrown) {
							alert( textStatus );
						});
					}

					function bindListeners()
					{
						$('.remove').unbind('click').on('click', function (e) {
							var id = $(this).data('id');
							var floor = $(this).data('floor');
							var row = $(this).parents('.well');
							$.ajax({
								type: "POST",
								url: "index.php",
								dataType: "JSON",
								data: { method: "remove", id: id, floor: floor }
							}).done(function() { 
								$(row).fadeOut().remove();
							}).fail(function(jqXHR, textStatus, errorThrown) {
								alert( textStatus );
							});
						});

						$('.edit').unbind('click').on('click', function (e) {
							$('.modal-title').html('Редактировать арендатора');
							$('.modal-footer .btn-primary').html('Сохранить');
							$('#method').val('edit');

							var id = $(this).data('id');
							$('#id').val(id);

							var floor = $(this).data('floor');
							$('#floor').val(floor);

							$.ajax({
								type: "POST",
								url: "index.php",
								dataType: "JSON",
								data: { method: "get", id: id, floor: floor }
							}).done(function( data ) { 
								for (var key in data)
								{
									$('#' + key).val(data[key]);
								}
							}).fail(function(jqXHR, textStatus, errorThrown) {
								alert( textStatus );
							});
						});

						function _move(id, floor, direction)
						{
							$.ajax({
								type: "POST",
								url: "index.php",
								dataType: "JSON",
								data: { method: "move", id: id, floor: floor, direction: direction }
							}).done(function( data ) { 
								refreshData();
							}).fail(function(jqXHR, textStatus, errorThrown) {
								alert( textStatus );
							});
						}

						$('.move-up').unbind('click').on('click', function (e) {
							var id = $(this).data('id');
							var floor = $(this).data('floor');
							var direction = 'up';
							_move(id, floor, direction);
						});

						$('.move-down').unbind('click').on('click', function (e) {
							var id = $(this).data('id');
							var floor = $(this).data('floor');
							var direction = 'down';
							_move(id, floor, direction);
						});
					}

					refreshData();
				<?php endif; ?>
			});
		</script>
    </div>
</body>
</html>