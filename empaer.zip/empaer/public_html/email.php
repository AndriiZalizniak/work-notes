<?php


if(!empty($_SERVER['HTTP_CLIENT_IP'])){
  $ip=$_SERVER['HTTP_CLIENT_IP'];
}elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
  $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
}else{
  $ip=isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'xx.xx.xx.xx';
}
    

if (isset($_GET['name'])) {
   $name = $_GET['name'];
}

if (isset($_GET['email'])) {
   $email = $_GET['email'];
}

if (isset($_GET['question'])) {
   $question = $_GET['question'];
}




$to = 'company@empaer-motors.com.ua';
$subject = "Вопрос с сайта empaer-motors.com.ua!";


$body = "Name: $name\n\n Email or Phone: $email\n\n Question: $question";
 
 
$headers = 'Content-type: text/html; charset=utf-8' . "\r\n";
 


if (mail($to, $subject, $body, $headers)) {
//if (true) {
   echo("1");
} else {
   echo("0");
}

?>